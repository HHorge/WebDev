

const express = require('express');
let router = express.Router();





/* GET users listing. */
router.get('/', function(req, res, next) {
  res.json([
    {id: 1, username: "Adrian"},
    {id: 2, username: "ricardo"},
    {id: 3, username: "milos"}
  ]);
});

module.exports = router;
