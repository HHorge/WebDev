//import every reducer here.
import counterReducer from './counter';
import {combineReducers} from 'redux';

const allReducers = combineReducers({
    counter : counterReducer
})

export default allReducers;



//App.js:
//Visualize:

//import {useSelector} from 'react-redux';
//const counter = useSelector(state => state.counter);

//Action:
//import {increment} from './actions';
//import {usedispatch} from 'react-redux';
//const dispatch = useDispatch();
//onClick{() => dispatch(increment)}