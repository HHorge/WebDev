import React, { Component } from 'react';
import './App.css';
import Header from './Components/Header/Header.js'
import Body from './Components/Body/Body.js'
import Details from './Components/Details/Details.js'
import {Route, BrowserRouter as Router} from 'react-router-dom';



class App extends Component {

  state = {users: []};
  
  componentDidMount(){
    fetch("/users")
      .then(res => res.json())
      .then(users => this.setState({users}));
  }
  render(){
    return (
    <div>

    <h1>Users</h1>
    <ul>
      {this.state.users.map(users =>
        <li key={users.id}>{users.username}</li>
        )}
    </ul>
      <Header/>
        <Router>
          <Route exact path='/' component={Body}/>
          <Route exact path='/details' component={Details}/>
        </Router>
    </div>
  );
  }
  
}

export default App;
