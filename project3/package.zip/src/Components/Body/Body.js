import React from 'react';
import './Body.css';

function Body(){
    return(
        <div className="App grid">
        <div className="Content"> hello</div>
        </div>
    );
}

export default Body;

