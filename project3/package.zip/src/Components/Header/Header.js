import React from 'react';
import './Header.css';

function Header(){
    return(
        <div className="header">
            ricardo is king
        </div>
    );
}

export default Header;