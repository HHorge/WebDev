//Component to display details about objects

import React from 'react';
import './Details.css';

function Details(){
    return(
        <div className="Content">
            hei
        </div>
    );
}

export default Details;
